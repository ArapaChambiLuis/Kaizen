/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import Modelo.DAO.ClienteUsuarioDAO;
import Modelo.Entidad.Cliente;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Arapa
 */
public class RegistrarCliente extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            
            ClienteUsuarioDAO objClienteDAO =new ClienteUsuarioDAO();
            
            String DNI = request.getParameter("DNI");
            String NOMBRE = request.getParameter("nombre");
            String APELLIDO = request.getParameter("apellido");
            String TELEFONO = request.getParameter("telefono");
            String FechaNAC = request.getParameter("fechanac");
            String NACION = request.getParameter("nacion");
            String CORREO = request.getParameter("correo");
            String CONTRASEÑA = request.getParameter("contraseña");
            

            Cliente objCliente = new Cliente();
            
            objCliente.setDNI(DNI);
            objCliente.setNomcli(NOMBRE);
            objCliente.setApecli(APELLIDO);
            objCliente.setTelcli(TELEFONO);
            objCliente.setFechana(FechaNAC);
            objCliente.setPais(NACION);
            objCliente.setTipo(objClienteDAO.tipoclienteprimerizo());
            objCliente.setCorreo(CORREO);
            objCliente.setContraseña(CONTRASEÑA);
            int status=objClienteDAO.usp_nuevocliente(objCliente);
            
            if(status>0){
                out.print("<script>alert(\"Se creo correctamente su registro\");</script>");
//                request.getRequestDispatcher("Inicio.jsp").include(request, response);
            }else{
                out.println("<div class='alert alert-danger'>"
                        + "<button type='button' class='close' data-dismiss='alert'>&times"
                        + "<Strong>Error: no se pudo Grabar</button>"
                        + "</div>");
            }
                         
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
