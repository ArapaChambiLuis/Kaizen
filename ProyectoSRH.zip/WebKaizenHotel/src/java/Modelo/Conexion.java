/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import java.sql.*;
import javax.swing.JOptionPane;

/**
 *
 * @author Bruno
 */
public class Conexion {
    static String Server="";
    static String port,database, username,password,driver;
    private static Connection cnx=null;
    
    
    private static String getConnectionUrl() {
        return Server + ":" + port + ";databaseName=" + database +";";
    }
    
    public static Connection obtener(){
        
        if(cnx==null){
            try{
                datos();        
                Class.forName(driver);
                cnx=DriverManager.getConnection(getConnectionUrl(),username,password);
             
            }catch(SQLException | ClassNotFoundException ex){
//                Actividadlog Log = new Actividadlog(Conexion.class.getName(),ex.getMessage());
                    JOptionPane.showMessageDialog(null, ex.getMessage(),"Error", 0); 
            }
        }return cnx;
    }
    
        public static void Cerrar(){
        try{
            if(cnx != null){
                cnx.close();
                cnx=null;
            }
        }catch(SQLException ex){
            JOptionPane.showMessageDialog(null, ex.getMessage().toString());
        }
    }
        
        private static void datos(){
        LeerXML objXML=new LeerXML();
        String[] Access = objXML.cargarXml();
        Server = Access[0];
        port=Access[1];
        database=Access[2];
        username=Access[3];
        password=Access[4];
        driver=Access[5];
        }
        
        public Conexion(){}
}
