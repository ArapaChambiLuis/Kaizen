/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo.DAO;

import Modelo.Actividadlog;
import Modelo.Conexion;
import Modelo.Entidad.Reserva;
import java.sql.*;



/**
 *
 * @author Bruno
 */
public class ReservaDAO {
    
    private static Connection con = null;
    
    public  int nuevareserva(Reserva re) {
        int status = 0;
        try {
            con = Conexion.obtener();//DataBase.getDBConnection();
            PreparedStatement ps = con.prepareStatement("exec usp_nuevareserva ?,?,?,?,?,?,?");
            ps.setString(1, re.getCodreser());
            ps.setString(2, re.getDNI());
            ps.setString(3, re.getFechaini());
            ps.setString(4, re.getFechafin());
            ps.setInt(5, re.getCanthabi());
            ps.setString(6, re.getTipohabi());
            ps.setFloat(7, re.getMonto());
             Actividadlog Log0 =new Actividadlog(ClienteUsuarioDAO.class.getName(),re.getDNI());
            status = ps.executeUpdate();
           
            Conexion.Cerrar();
        } catch (Exception ex) {
            Actividadlog Log =new Actividadlog(ReservaDAO.class.getName(),ex.getMessage());
            ex.printStackTrace();
        }
        return status;
    }
    
    public boolean disponible(String tipo){
        boolean respuesta=false;
        try {
            con = Conexion.obtener();//DataBase.getDBConnection();
            PreparedStatement ps = con.prepareStatement("exec usp_disponibilidadportipo ?");
            ps.setString(1,tipo);
            ResultSet Resultado=ps.executeQuery();
            while(Resultado.next()){
                if(((Number)Resultado.getObject(1)).intValue()>0){
                    respuesta=true;
                    break;
                }   
            } 
             Actividadlog Log =new Actividadlog(ReservaDAO.class.getName(),tipo);
            Conexion.Cerrar();
        } catch (Exception ex) {
            Actividadlog Log =new Actividadlog(ReservaDAO.class.getName(),ex.getMessage());
            respuesta=false;
        }
        return respuesta;
    }
    
    public String getCodigoReserva(){
        int numero=0;
        String codigo="";
        try {
            con = Conexion.obtener();//DataBase.getDBConnection();
            PreparedStatement ps = con.prepareStatement("exec usp_tamañohistorial");
            ResultSet Resultado=ps.executeQuery();
            
            while(Resultado.next()){
                numero=((Number)Resultado.getObject(1)).intValue()+1;
                String n = Integer.toString(numero);
                if(n.length()==2){
                    codigo= "reser00"+numero;break;
                }else if(n.length()==3){
                    codigo= "reser0"+numero;break;
                }else{
                    codigo= "reser"+numero;break;
                }
            }
              Actividadlog Log =new Actividadlog(ReservaDAO.class.getName(),codigo);
            Conexion.Cerrar();
        } catch (Exception ex) {
            Actividadlog Log =new Actividadlog(ReservaDAO.class.getName(),ex.getMessage());
        }
        return codigo;
    }
    
    public float Montototal(String TipoHabi, int CantHabi, float desc ){
        float Monto;
        if(TipoHabi.compareTo("hatipo0001")==0){
                Monto = (90*CantHabi)-desc;
            }else if(TipoHabi.compareTo("hatipo0002")==0){
                Monto = (100*CantHabi)-desc;
            }else if(TipoHabi.compareTo("hatipo0003")==0){            
                Monto = (120*CantHabi)-desc;
            }else if(TipoHabi.compareTo("hatipo0004")==0){
                Monto = (110*CantHabi)-desc;
             }else{
                Monto = (130*CantHabi)-desc;
            }
        return Monto;
    }
    
        public float GetDescuento(String tipocli){
        float desc=0;
        try{        
        con=Conexion.obtener();
        PreparedStatement ps = con.prepareStatement("exec usp_getdescuento ?");
        ps.setString(1,tipocli);
        ResultSet Resultado=ps.executeQuery();
        while(Resultado.next()){  
                desc=Resultado.getFloat("des_espe");
            }
                              
        Conexion.Cerrar();
        }catch(SQLException ex){
            Actividadlog Log =new Actividadlog(ReservaDAO.class.getName(),ex.getMessage());
            ex.printStackTrace();
        }
        return desc;
    }
}
