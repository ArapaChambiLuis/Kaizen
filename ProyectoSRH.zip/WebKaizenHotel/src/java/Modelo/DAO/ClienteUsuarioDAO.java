/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo.DAO;

import Modelo.Actividadlog;
import Modelo.Conexion;
import Modelo.Entidad.Cliente;
import java.sql.*;
import javax.swing.JOptionPane;

public class ClienteUsuarioDAO {
    private static Connection con = null;
    public boolean GetContraseñaCliente(String DNI, String Contraseña){
        boolean respuesta=false;
        try{
             con=Conexion.obtener();
            PreparedStatement Consulta = con.prepareStatement("exec usp_getclavecliente ?");
            Consulta.setString(1,DNI);
            
            ResultSet Resultado=Consulta.executeQuery();
            while(Resultado.next()){
                if(Resultado.getString("contra_login").equals(Contraseña)){
                    respuesta=true; break;
                }
            }
            Conexion.Cerrar();
        }catch(Exception ex){
            respuesta=false;
        }
        return respuesta;
    }
    public int usp_nuevocliente(Cliente x){
        int status = 0;
        try {
            
            con=Conexion.obtener();
            PreparedStatement ps = con.prepareStatement("exec usp_nuevocliente ?,?,?,?,?,?,?,?,?");
            ps.setString(1,x.getDNI());
            ps.setString(2,x.getNomcli());
            ps.setString(3,x.getApecli());
            ps.setString(4,x.getTelcli());
            ps.setString(5,x.getFechana());
            ps.setString(6,x.getPais());
            ps.setString(7,x.getTipo());
            ps.setString(8,x.getCorreo());
            ps.setString(9,x.getContraseña());
            
//            Actividadlog Log0 =new Actividadlog(ClienteUsuarioDAO.class.getName(),x.getDNI());
            status = ps.executeUpdate();
           
            Conexion.Cerrar();
        } catch (SQLException ex) {
            Actividadlog Log =new Actividadlog(ReservaDAO.class.getName(),ex.getMessage());
            ex.printStackTrace();
        }
        return status;
    }
    
    
    public String Tipocliente(String DNI, String AÑO){
        String tipo="";
        try{
            int veces=0;
            float monto=0;
            con=Conexion.obtener();
            
            PreparedStatement ps = con.prepareStatement("exec usp_frecuenciaAñoporDNI ?,?");
            ps.setString(1,DNI);
            ps.setString(2,AÑO);
            ResultSet Resultado=ps.executeQuery();
            while(Resultado.next()){
                    veces=((Number)Resultado.getObject(1)).intValue(); 
                }         

            PreparedStatement ps2 = con.prepareStatement("exec usp_montoAñoporDNI ?,?");
            ps2.setString(1,DNI);
            ps2.setString(2,AÑO);
            ResultSet Resultado2=ps2.executeQuery();
            while(Resultado2.next()){
                    monto=((Number)Resultado2.getObject(1)).intValue();  
                }  
          
            if(veces<=4 && monto<=270){
                tipo="ticli0001";
                PreparedStatement ps3 = con.prepareStatement("exec usp_actualizartipocliente ?,?");
                ps3.setString(1,DNI);
                ps3.setString(2,tipo);
                ps3.executeUpdate();
            }
            else if(veces<=6 && monto<=450){
                tipo="ticli0002";
                PreparedStatement ps3 = con.prepareStatement("exec usp_actualizartipocliente ?,?");
                ps3.setString(1,DNI);
                ps3.setString(2,tipo);
                ps3.executeUpdate();
            }else if(veces<=8 && monto<=630){
                tipo="ticli0003";
                PreparedStatement ps3 = con.prepareStatement("exec usp_actualizartipocliente ?,?");
                ps3.setString(1,DNI);
                ps3.setString(2,tipo);
                ps3.executeUpdate();
            }else if(veces>8 && monto>630){
                tipo="ticli0004";
                PreparedStatement ps3 = con.prepareStatement("exec usp_actualizartipocliente ?,?");
                ps3.setString(1,DNI);
                ps3.setString(2,tipo);
                ps3.executeUpdate();
            }
            Conexion.Cerrar(); 
        }catch(SQLException ex){
            Actividadlog Log =new Actividadlog(ReservaDAO.class.getName(),ex.getMessage());
            ex.printStackTrace();
        }
        return tipo;
    }
    
    public String tipoclienteprimerizo(){
        String tipo;
        tipo="ticli0001";
        return tipo;
    }
    
}
