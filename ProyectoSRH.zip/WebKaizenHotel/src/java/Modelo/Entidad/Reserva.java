/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo.Entidad;

/**
 *
 * @author Bruno
 */
public class Reserva {
    String codreser, DNI, fechaini, fechafin, tipohabi;
    int canthabi;
    float monto;

    public String getCodreser() {
        return codreser;
    }

    public void setCodreser(String codreser) {
        this.codreser = codreser;
    }

    public String getDNI() {
        return DNI;
    }

    public void setDNI(String DNI) {
        this.DNI = DNI;
    }

    public String getFechaini() {
        return fechaini;
    }

    public void setFechaini(String fechaini) {
        this.fechaini = fechaini;
    }

    public String getFechafin() {
        return fechafin;
    }

    public void setFechafin(String fechafin) {
        this.fechafin = fechafin;
    }

    public String getTipohabi() {
        return tipohabi;
    }

    public void setTipohabi(String tipohabi) {
        this.tipohabi = tipohabi;
    }

    public int getCanthabi() {
        return canthabi;
    }

    public void setCanthabi(int canthabi) {
        this.canthabi = canthabi;
    }

    public float getMonto() {
        return monto;
    }

    public void setMonto(float monto) {
        this.monto = monto;
    }
    
    
}
